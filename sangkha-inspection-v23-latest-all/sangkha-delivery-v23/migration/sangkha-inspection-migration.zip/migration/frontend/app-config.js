/* Migration bridge: replace only this public API URL after deploying the Workers backend. Never put API keys here. */
window.SANGKHA_CONFIG = Object.freeze({
  API_BASE_URL: "https://REPLACE-WITH-YOUR-WORKER.workers.dev"
});
